<!DOCTYPE html>
<html>
<head>
    <title>Project Blog</title>
</head>
<body>
    <h1>Project Blog</h1>

    <h4>Week 5: Oct 3rd, 2023</h4>
    <ul>
        <li>Discussed the usage of implementation of WebSite.php</li>
        <li>Discussed deliverable 1.</li>
        <li>Asked to research about the binary format of HTTP/2</li>
    </ul>

    <h4>Week 3: Sept 19th, 2023</h4>
    <p>Notes from professor:</p>
    <ul>
        <li>Try setting up using "other email client"</li>
        <li>Read about sendmail (dad of postfix). It's the simplified version of these</li>
        <li>Small project - convert your page to be shown using atto's web server. 3 different routes for bio, blog, and proposal.</li>
        <li>Trace the code - the function calls that are done when the weblog is shown</li>
        <li>Look at the examples and try to run them. They are mainly for the web servers.</li>
    </ul>

    <h4>Week 2: Sept 12th, 2023</h4>
    <ul>
        <li>Discussed the implementation of the project.</li>
        <li>Defined deliverables and worked out technicalities of the course.</li>
    </ul>

    <h4>Week 1: Sept 5th, 2023</h4>
    <ul>
        <li>Discussed about the proposal.</li>
        <li>Overview of the project.</li>
        <li>Professor gave some resources to educate myself on the topic.</li>
    </ul>
</body>
</html>
